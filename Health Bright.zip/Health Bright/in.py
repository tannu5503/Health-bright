from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# Route for kitchen meal builder page
@app.route('/kitchen', methods=['GET', 'POST'])
def kitchen():
    return render_template('kitchen.html')  # your HTML file should be named kitchen.html

# Optional: API route if you want to move API logic to backend
@app.route('/get_meals', methods=['POST'])
def get_meals():
    data = request.json
    ingredients = data.get('ingredients', '')
    
    api_key = '28f561b9035f499ca42abc55a5b17f22'  # 🔐 Replace with env var for real use
    url = f"https://api.spoonacular.com/recipes/findByIngredients?ingredients={ingredients}&number=3&ranking=1&apiKey={api_key}"

    try:
        response = requests.get(url)
        meal_data = response.json()
        return jsonify({'meals': meal_data})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
