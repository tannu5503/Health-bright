import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
import pickle

# Load Data
df = pd.read_csv('dandss.csv')

# Preprocess symptoms into consistent lowercase without spaces
df['Symptoms'] = df['Symptoms'].str.lower().str.replace(' ', '').str.replace('_', '')

# Build complete symptom set
all_symptoms = set()
for symptom_list in df['Symptoms']:
    symptoms = symptom_list.split(',')
    all_symptoms.update(symptoms)

# Create multi-hot encoding for symptoms
for symptom in all_symptoms:
    df[symptom] = df['Symptoms'].apply(lambda x: 1 if symptom in x else 0)

# Encode Disease labels
le = LabelEncoder()
df['Disease'] = le.fit_transform(df['Disease'])

# Prepare features & labels
X = df[list(all_symptoms)]
y = df['Disease']

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Model
model = DecisionTreeClassifier()
model.fit(X_train, y_train)

# Save everything
with open('disease_model.pkl', 'wb') as f:
    pickle.dump(model, f)

with open('disease_encoder.pkl', 'wb') as f:
    pickle.dump(le, f)

with open('symptom_columns.pkl', 'wb') as f:
    pickle.dump(X.columns.tolist(), f)

print("✅ Model retrained and saved successfully!")
