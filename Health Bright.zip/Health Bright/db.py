import sqlite3

# Connect to the database file
conn = sqlite3.connect("health_bright.db")

# Create a cursor object
cursor = conn.cursor()

# Execute a query to fetch table names
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()
print("Tables in the database:", tables)

# Read data from a specific table (replace 'your_table' with the actual table name)
cursor.execute("SELECT * FROM users;")
rows = cursor.fetchall()

# Print the first few rows
for row in rows[:5]:  # Print first 5 rows
    print(row)

# Close the connection
conn.close()
