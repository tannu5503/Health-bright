import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

# Load updated dataset
df = pd.read_csv("diet_recommendations_updated.csv")

# Encode categorical variables
le_bmi = LabelEncoder()
df["BMI_Category"] = le_bmi.fit_transform(df["BMI_Category"])

le_allergy = LabelEncoder()
df["Allergy"] = le_allergy.fit_transform(df["Allergy"])

le_preference = LabelEncoder()
df["Dietary_Preference"] = le_preference.fit_transform(df["Dietary_Preference"])

le_chronic = LabelEncoder()
df["Chronic_Disease"] = le_chronic.fit_transform(df["Chronic_Disease"])

# Combine diet columns into structured format
df["Diet"] = (
    "Breakfast: " + df["Breakfast"] + " | " +
    "Lunch: " + df["Lunch"] + " | " +
    "Dinner: " + df["Dinner"] + " | " +
    "Snacks: " + df["Snacks"]
)

le_diet = LabelEncoder()
df["Diet"] = le_diet.fit_transform(df["Diet"])

# Features and target
X = df[["Height", "Weight", "BMI_Category", "Allergy", "Dietary_Preference", "Chronic_Disease"]]
y = df["Diet"]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)

# Save model and encoders
pickle.dump(rf, open("predict_diet.pkl", "wb"))
pickle.dump(le_bmi, open("encoder_bmi.pkl", "wb"))
pickle.dump(le_allergy, open("encoder_allergy.pkl", "wb"))
pickle.dump(le_preference, open("encoder_preference.pkl", "wb"))
pickle.dump(le_diet, open("encoder_diet.pkl", "wb"))
pickle.dump(le_chronic, open("encoder_chronic.pkl", "wb"))

print("Model training complete. Files saved: predict_diet.pkl, encoder_bmi.pkl, encoder_allergy.pkl, encoder_preference.pkl, encoder_diet.pkl, encoder_chronic.pkl")
