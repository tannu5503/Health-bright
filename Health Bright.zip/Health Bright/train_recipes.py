import pandas as pd
import pickle
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder

# Load data
df = pd.read_csv('Food_Options_and_Recipes.csv')

# Rename columns (adjust if your file has different names)
df = df.rename(columns={
    'Food Item': 'Food_Item',
    'Detailed Recipe': 'Recipe',
    'YouTube Link': 'Link',
    'Image URL': 'Image',
    'Protein (g)': 'Protein',
    'Fat (g)': 'Fat',
    'Carbs (g)': 'Carbs'
})

# Encode Food Item
le = LabelEncoder()
df['Food_Item_Encoded'] = le.fit_transform(df['Food_Item'])

# Features
X = df[['Food_Item_Encoded']]

# Train one model for each column we want to predict
models = {}
for column in ['Recipe', 'Link', 'Image', 'Protein', 'Fat', 'Carbs']:
    model = DecisionTreeClassifier()
    model.fit(X, df[column])
    models[column] = model

# Save everything
with open('recipe_models.pkl', 'wb') as f:
    pickle.dump(models, f)

with open('food_encoder.pkl', 'wb') as f:
    pickle.dump(le, f)

print("✅ All models trained and saved!")
