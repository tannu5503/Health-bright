import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import re  # For regex-based text cleaning

# Load dataset
df = pd.read_csv("full_exercise_recommendation.csv")

# Strip spaces from column names
df.columns = df.columns.str.strip()

# 🔹 Clean "Duration" column: Extract first number found
df["Duration"] = df["Duration"].astype(str).apply(lambda x: re.search(r"\d+", x).group() if re.search(r"\d+", x) else 10).astype(float)

# 🔹 Clean "Steps" column: Extract first number found (or default to 100)
df["Steps"] = df["Steps"].astype(str).apply(lambda x: re.search(r"\d+", x).group() if re.search(r"\d+", x) else 100).astype(float)

# Encode categorical variables
le_type = LabelEncoder()
df["Exercise_Type"] = le_type.fit_transform(df["Exercise_Type"])
le_name = LabelEncoder()
df["Exercise_Name"] = le_name.fit_transform(df["Exercise_Name"])
le_intensity = LabelEncoder()
df["Intensity"] = le_intensity.fit_transform(df["Intensity"])

# Features and target
X = df[["Exercise_Type", "Steps", "Duration", "Intensity"]]  # Ensure correct column names
y = df["Exercise_Name"]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)

# Save model and encoders
pickle.dump(rf, open("predict_exercise.pkl", "wb"))
pickle.dump(le_type, open("encoder_exercise_type.pkl", "wb"))
pickle.dump(le_name, open("encoder_exercise_name.pkl", "wb"))
pickle.dump(le_intensity, open("encoder_exercise_intensity.pkl", "wb"))

print("✅ Exercise model training complete! Files saved.")
